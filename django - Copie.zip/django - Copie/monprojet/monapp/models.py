from django.db import models

class Candidat(models.Model):
    nom = models.CharField(max_length=100)
    email = models.EmailField()
    cv = models.FileField(upload_to='cvs/') 
    
    def __str__(self):
        return self.nom

class Recruteur(models.Model):
    entreprise = models.CharField(max_length=100)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.entreprise
