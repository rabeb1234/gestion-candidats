from rest_framework import viewsets, mixins
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import Candidat, Recruteur
from .serializers import CandidatSerializer, RecruteurSerializer

class CandidatViewSet(viewsets.ModelViewSet):
    queryset = Candidat.objects.all()
    serializer_class = CandidatSerializer

    def destroy(self, request, pk=None):
        """
        Méthode DELETE pour supprimer un candidat
        """
        candidat = get_object_or_404(Candidat, pk=pk)
        candidat.delete()
        return Response({"message": "Candidat supprimé avec succès"}, status=status.HTTP_204_NO_CONTENT)

class RecruteurViewSet(viewsets.ModelViewSet):
    queryset = Recruteur.objects.all()
    serializer_class = RecruteurSerializer
